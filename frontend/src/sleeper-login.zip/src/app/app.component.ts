import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, LoginComponent],
  template: `
    <h1>Welcome to Sleeper Login</h1>
    <app-login></app-login>
  `,
  styles: []
})
export class AppComponent {}
