import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  validateUser(username: string): Observable<{ user_id?: string }> {
    if (username.length > 3) {
      return of({ user_id: '12345' });
    }
    return of({});
  }
}
