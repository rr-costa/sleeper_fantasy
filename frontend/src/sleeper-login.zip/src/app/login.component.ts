import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div>
      <input #inputUser type="text" [(ngModel)]="username" placeholder="Enter Sleeper username" />
      <button (click)="signIn()">Sign In</button>
      <button *ngIf="isLoggedIn" (click)="confirmSignOut()">Sign Out</button>
      <p *ngIf="errorMessage" style="color: red;">{{ errorMessage }}</p>
    </div>
  `,
  styles: []
})
export class LoginComponent {
  username = '';
  isLoggedIn = false;
  errorMessage = '';

  @ViewChild('inputUser') inputUser!: ElementRef;

  constructor(private loginService: LoginService) {
    const stored = localStorage.getItem('sleeperUser');
    if (stored) {
      this.isLoggedIn = true;
    }
  }

  signIn() {
    if (!this.username.trim()) {
      this.errorMessage = 'Please insert your Sleeper user';
      this.focusInput();
      return;
    }

    this.loginService.validateUser(this.username).subscribe(res => {
      if (res?.user_id) {
        localStorage.setItem('sleeperUser', this.username);
        this.isLoggedIn = true;
        this.errorMessage = '';
        this.username = '';
      } else {
        this.errorMessage = 'User not found, please check the login and try again';
        this.focusInput();
      }
    });
  }

  confirmSignOut() {
    if (confirm('Do you really want to sign out?')) {
      localStorage.removeItem('sleeperUser');
      this.isLoggedIn = false;
      this.errorMessage = '';
      this.username = '';
      this.focusInput();
    }
  }

  private focusInput() {
    setTimeout(() => {
      this.inputUser.nativeElement.focus();
      this.inputUser.nativeElement.select();
    }, 0);
  }
}
